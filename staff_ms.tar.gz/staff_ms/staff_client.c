#include "staff_ms.h"
#define SERVER_IP    "192.168.2.142"
#define SERVER_PORT  6666
int do_sigin(int, accout_password*);
int do_login(int,accout_password*);
int do_insert(int ,staff_msg*);
int do_modify(int ,staff_msg*);
int do_look(int ,staff_msg*pmsg);
int do_adminlogin(int ,accout_password*);
int do_del(int ,staff_msg*);
char yourname[30];
float modify_salary;
int modify_id,modify_iphone;
char modify_name[20];
char modify_sex;
//主函数---------------------------------------------------
int main(int argc, const char *argv[])
{
	int sockfd;
	struct sockaddr_in server_addr;
	//建立套接字
	if((sockfd=socket(AF_INET,SOCK_STREAM,0))<0)
	{
		perror("failed in socket");
		return -1;
	}
	//填充服务器结构体
	server_addr.sin_family=AF_INET;
	server_addr.sin_port=htons(SERVER_PORT);
	server_addr.sin_addr.s_addr=inet_addr(SERVER_IP);
	puts("填充完成");

	//connect服务器
	if((connect(sockfd,(struct sockaddr*)&server_addr,sizeof(server_addr)))<0)
	{
		perror("connect failed");
		return -1;
	}
	puts("已经连接服务器--------------------------------------------------");
	puts("--------------------------欢迎进入员工管理系统------------------");
	//puts("------------0退出，1插入，2删除，3修改，4查看-------------------");
	//while循环判断命令
	enum cmd cd;
	staff_msg staff_info;//存放员工信息
	accout_password ap;//存放用户名和密码
	while(1)
	{
		puts("------0 退出，7 用户登录，8 管理员登录， 9 注册-----------------");
		puts("请输入要操作的命令:");
		scanf("%d",&ap.type);
		switch (ap.type)
		{
		case EXIT:
			exit(0);
			break;
		case LOGIN:
			do_login(sockfd,&ap);//用户登录函数
			break;
		case ADMINLG:
			do_adminlogin(sockfd,&ap);//管理员登录成功后权限
			break;
		case SIGIN:
			do_sigin(sockfd,&ap);//注册函数
			break;
		default:
			break;
		}
	}
	return 0;
}
//注册函数--------
int do_sigin(int sockfd,accout_password*msg)
{
	bzero(msg,sizeof(accout_password));
	puts("请输入username：");
	scanf("%s",msg->name);
	//printf("输入的用户名为%s\n",msg->name);//打印输入的用户名
	puts("请输入密码：");
	scanf("%s",msg->password);//得设置不回显
	msg->type=SIGIN;
	if(send(sockfd,msg,sizeof(accout_password),0)<0)
	{
		puts("sigin_send failed");
		return -1;
	}
	bzero(msg,sizeof(accout_password));

	if(recv(sockfd,msg,sizeof(accout_password),0)<0)
	{
		puts("sigin_recv failed");
		return -1;
	}
	if(strcmp(msg->password,"ok")==0)
	{
		puts("注册成功");
		return 0;
	}
	else if(strcmp(msg->password,"no")==0)
	{
		puts("注册失败");
		return -1;
	}
}
//管理员登录成功后权限-----------
int do_adminlogin(int sockfd,accout_password*msg)
{
	bzero(msg,sizeof(accout_password));
	staff_msg staff_MSG2;//用户管理员登录时通信
	puts("请输管理员账号：");
	scanf("%s",msg->name);
	strcpy(yourname,msg->name);//用户只能修改和查询自己的消息
	puts("请输入密码：");
	scanf("%s",msg->password);//得设置不回显
	msg->type=ADMINLG;	
	if(send(sockfd,msg,sizeof(accout_password),0)<0)
	{
		puts("adminlogin_send failed");
		return -1;
	}
	bzero(msg,sizeof(accout_password));
	if(recv(sockfd,msg,sizeof(accout_password),0)<0)
	{
		puts("adminlogin_recv failed");
		return -1;
	}
	if(strcmp(msg->password,"ok")==0)
	{
		puts("登录成功");

		puts("-------------------------您是管理员---------------------------");
		while(1)
		{
			puts("------------0退出，1插入，2，删除，3修改，4查看-------------------");
			puts("请输入要操作的命令：");
			scanf("%d",&msg->type);
			switch(msg->type)
			{
			case EXIT:
				exit(0);
				break;
			case INSERT://插入
				do_insert(sockfd,&staff_MSG2);
				break;
			case MODIFY://修改函数
				puts("请输入要修改的name:");
				scanf("%s",staff_MSG2.name);
				do_look(sockfd,&staff_MSG2);
				do_modify(sockfd,&staff_MSG2);
				puts("修改后");
				do_look(sockfd,&staff_MSG2);
				break;
			case LOOK://查询函数p
				bzero(&staff_MSG2,sizeof(staff_MSG2));

				puts("请输入要查询员工的name：");
				scanf("%s",staff_MSG2.name);
				do_look(sockfd,&staff_MSG2);
				break;
			case DEL:
				do_del(sockfd,&staff_MSG2);
				break;
			default:
				break;
			}
		}
	}
	else if(strcmp(msg->password,"no")==0)
	{
		puts("登录失败，请重试");
		return -1;
	}
	return 0;
}
//用户登录成功后权限-------------
int do_login(int sockfd,accout_password*msg)
{
	bzero(msg,sizeof(accout_password));
	staff_msg staff_MSG;
	puts("请输入登录用户名：");
	scanf("%s",msg->name);
	strcpy(yourname,msg->name);//用户只能修改和查询自己的消息
	//	printf("输入的用户名为%s\n",msg->name);//打印输入的用户名
	puts("请输入密码：");
	scanf("%s",msg->password);//得设置不回显
	msg->type=LOGIN;
	//判断是否登录成功
	if(send(sockfd,msg,sizeof(accout_password),0)<0)
	{
		puts("login_send failed");
		return -1;
	}
	bzero(msg,sizeof(accout_password));
	if(recv(sockfd,msg,sizeof(accout_password),0)<0)
	{
		puts("sigin_recv failed");
		return -1;
	}
	if(strcmp(msg->password,"ok")==0)
	{
		puts("登录成功");
		puts("-------------------------您是普通用户---------------------------");
		while(1)
		{
			puts("------------0退出，3修改，4查看-------------------");
			puts("请输入要操作的命令：");
			scanf("%d",&msg->type);
			switch(msg->type)
			{
			case EXIT:
				exit(0);
				break;
				//	case INSERT://插入
				//	do_insert(sockfd,&staff_MSG);
				//	break;
			case MODIFY://修改函数
				strcpy(staff_MSG.name,yourname);
				do_look(sockfd,&staff_MSG);
				do_modify(sockfd,&staff_MSG);
				puts("修改后");
				do_look(sockfd,&staff_MSG);
				break;
			case LOOK://查询函数p
				bzero(&staff_MSG,sizeof(staff_MSG));

				puts("请输入要查询员工的name：");
				scanf("%s",staff_MSG.name);

				do_look(sockfd,&staff_MSG);
				break;
			default:
				break;
			}
		}
	}
	else if(strcmp(msg->password,"no")==0)
	{
		puts("登录失败，请重试");
		return -1;
	}
	return 0;
}
//插入信息函数(管理员权限)-------------
int  do_insert(int sockfd,staff_msg*PMSG)
{
	puts("请依次输入需要插入的信息：id name sex iphone salary ");
	bzero(PMSG,sizeof(staff_msg));
	PMSG->cmd=INSERT;
	scanf("%d %s %c %d %f",&PMSG->id,PMSG->name,&PMSG->sex,&PMSG->iphone,&PMSG->salary);
	printf("%d %s %c %d %f\n",PMSG->id,PMSG->name,PMSG->sex,PMSG->iphone,PMSG->salary);
	if(send(sockfd,PMSG,sizeof(staff_msg),0)<0)
	{
		puts("insert_send failed");
		return -1;
	}
	bzero(PMSG,sizeof(staff_msg));
	if(recv(sockfd,PMSG,sizeof(PMSG),0)<0)
	{
		puts("insert_recv failed");
		return -1;
	}
	if(strcmp(PMSG->name,"ok")==0)
	{
		puts("插入成功");
	}
	else if(strcmp(PMSG->name,"no")==0)
	{
		puts("插入失败");
		return -1;
	}
}
//修改函数
int do_modify(int sockfd,staff_msg*pmsg)
{

	printf("%s\n",pmsg->name);
	char type='a';
	while(getchar()!='\n');
	puts("是否需要修改id(y/n)");
	scanf("%c",&type);
	if(type=='y')
	{
		puts("请输入新id:");
		scanf("%d",&pmsg->id);
	}


	if(strcmp(yourname,"admin")==0)//管理员可以修改name
	{
		while(getchar()!='\n');
		type='a';
		puts("是否需要修改name(y/n)");
		scanf("%c",&type);
		if(type=='y')
		{
			puts("请输入新name:");
			scanf("%s",pmsg->name);
		}
	}
	while(getchar()!='\n');
	type='a';

	puts("是否需要修改sex(y/n)");
	scanf("%c",&type);
	if(type=='y')
	{
		puts("请输入新sex:");
		scanf("%s",&pmsg->sex);
	}
	type='a';
	while(getchar()!='\n');
	puts("是否需要修改iphone(y/n)");
	scanf("%c",&type);
	if(type=='y')
	{
		puts("请输入新iphone:");
		scanf("%d",&pmsg->iphone);
	}
	if(strcmp(yourname,"admin")==0)//管理员可以修改salary
	{
		while(getchar()!='\n');
		type='a';
		puts("是否需要修改salary(y/n)");
		scanf("%c",&type);
		if(type=='y')
		{
			puts("请输入新salary:");
			scanf("%f",&pmsg->salary);
		}

	}

	pmsg->cmd=MODIFY;//填充操作码
	//发送消息给服务器
	if(send(sockfd,pmsg,sizeof(staff_msg),0)<0)
	{
		puts("modify_send failed");
		return -1;
	}
	return 0;
}

//查询函数----------
int do_look(int sockfd,staff_msg*pmsg)
{
	char name[100]={};
	int ret;
	strcpy(name,pmsg->name);//保存当前登录用户名
	pmsg->cmd=LOOK;	
	if(send(sockfd,pmsg,sizeof(staff_msg),0)<0)
	{
		puts("look_send failed");
		return -1;
	}
	recv(sockfd,pmsg,sizeof(staff_msg),0);
	if(pmsg->cmd==-1)
	{
		puts("无此用户");
		return -1;
	}
	//从服务器接收消息
	bzero(pmsg,sizeof(staff_msg));
	do
	{
		ret=recv(sockfd,pmsg,sizeof(staff_msg),0);
	}while(ret<0&&EINTR==errno);
	if(ret<0)
	{
		puts("look_recv failed");
		return -1;
	}
	if((strcmp(name,yourname)==0)||(strcmp(yourname,"admin")==0))
	{
		puts("查询结果如下---------------------------");
		printf("id:%d name:%s sex:%c iphone:%d salary:%f\n",\
				pmsg->id,pmsg->name,pmsg->sex,pmsg->iphone,pmsg->salary);
		modify_salary=pmsg->salary;
		modify_id=pmsg->id;
		modify_iphone=pmsg->iphone;
		modify_sex=pmsg->sex;
		strcpy(modify_name,pmsg->name);
	}
	else 
	{
		puts("查询结果如下----------------------------------");
		printf("id:%d name:%s sex:%c iphone:%d \n",\
				pmsg->id,pmsg->name,pmsg->sex,pmsg->iphone);
	}
	return 0;
}
//删除
int do_del(int sockfd,staff_msg*pmsg)
{
	int ret;
	pmsg->cmd=DEL;
	puts("请输入您需要删除的name:");
	scanf("%s",pmsg->name);
	//判断是否有该用户存在
	if(send(sockfd,pmsg,sizeof(staff_msg),0)<0)
	{
		puts("look_send failed");
		return -1;
	}
	recv(sockfd,pmsg,sizeof(staff_msg),0);
	if(pmsg->cmd==-1)
	{
		puts("无此用户");
		return -1;
	}

	//--------------------此时已经可以发送要删除的信息

	if(send(sockfd,pmsg,sizeof(staff_msg),0)<0)
	{
		puts("look_send failed");
		return -1;
	}
	bzero(pmsg,sizeof(staff_msg));
	do
	{
		ret=recv(sockfd,pmsg,sizeof(staff_msg),0);
	}while(ret<0&&EINTR==errno);
	if(ret<0)
	{
		puts("look_recv failed");
		return -1;
	}

	if(pmsg->id==-1)
	{
		puts("删除失败");
	}
	else if(pmsg->id==0)
		puts("删除成功");
}
