#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netinet/ip.h> 
#include<arpa/inet.h> 
#include<sys/types.h>    
#include<stdlib.h>
#include<sqlite3.h>
#include<strings.h>
#include<string.h>
#include<errno.h>
#include<pthread.h>
      //员工消息结构体
typedef struct {
	char name[20];
	int id;
	char sex;
	int iphone;
	float salary; 
	int cmd;
	char date[300];
}staff_msg;
	

//用户信息结构体
typedef struct {
	int type;
		char name[20];
		char password[30];
}accout_password;
//操作命令枚举体
enum cmd{
	EXIT,//退出
	INSERT,//插入
	DEL,//删除
	MODIFY,//修改
	LOOK,//查询
	LOGIN=7,//用户登录
	ADMINLG,//管理员登录
	SIGIN,//注册
};
