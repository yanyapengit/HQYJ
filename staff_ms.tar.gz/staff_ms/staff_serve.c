#include"staff_ms.h"
#include <unistd.h>
struct fd_addr{
	int acceptfd;
	struct sockaddr_in client_addr;
	sqlite3 * newdb;
};
char sql[100];
int ret;
char *errmsg;
staff_msg  staff_MSG;
pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;//初始化互斥锁
//pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;

int do_login(int,struct fd_addr*,accout_password*);
void do_client(struct fd_addr*);
void do_sigin(int,struct fd_addr*,accout_password*);
int do_insert(int,struct fd_addr*);
int do_modify(int ,struct fd_addr*);
int do_look(int, struct fd_addr*);
int history_callback(void *,int ,char**,char**);
int search(int ,void *arg,int f_num,char**f_value,char**f_name);
int do_adminlogin(int,struct fd_addr*,accout_password*);
int do_del(int ,struct fd_addr*arg);

//	主函数-------------------------------
int main(int argc, const char *argv[])
{
	//建立数据库

	sqlite3 *db;
	if(sqlite3_open("stff_ms.db",&db)!=SQLITE_OK)
	{
		printf("%s\n",sqlite3_errmsg(db));
		return -1;
	}
	else
	{
		puts("成功打开数据库");
	}
	//创建员工信息表和用户密码表

	char *create_infotable="create table if not exists staffinfo(id int primary key,name string,sex char,iphone int,salary float)";
	char *create_password="create table if not exists password(username string primary key,password int)";
	if(sqlite3_exec(db,create_infotable,NULL,NULL,&errmsg)!=SQLITE_OK)
	{
		printf("%s\n",errmsg);
	}
	else{
		puts("创建员工信息表成功");
	}
	if(sqlite3_exec(db,create_password,NULL,NULL,&errmsg)!=SQLITE_OK)
	{
		printf("%s\n",errmsg);
	}
	else{
		puts("创建用户密码表成功");
	}
	//建立套接字
	struct fd_addr acfd_caddr;
	acfd_caddr.newdb=db;//填充newdb数据库句柄--------------------------
	int sockfd;
	struct sockaddr_in server_addr;
	if((sockfd=socket(AF_INET,SOCK_STREAM,0))<0)
	{
		perror("socket failed");
		return -1;
	}
	//允许地址快速重用
	int reuse =1;
	setsockopt(sockfd,SOL_SOCKET,SO_REUSEADDR,&reuse,sizeof(reuse));
	//填充服务器结构体
	server_addr.sin_family=AF_INET;
	server_addr.sin_port=htons(6666);
	server_addr.sin_addr.s_addr=inet_addr("0.0.0.0");
	//bind绑定
	if((bind(sockfd,(struct sockaddr*)&server_addr,sizeof(server_addr)))<0)
	{
		perror("bind failed");
		return -1;
	}
	//listen监听
	if((listen(sockfd,10))<0)
	{
		perror("listen failed");
		return -1;
	}
	socklen_t clientlen=sizeof(acfd_caddr.client_addr);
	pthread_t tid;
	//accept，并创建创建线程
	puts("服务器已经启动");
	while(1)
	{
		if((acfd_caddr.acceptfd=accept(sockfd,(struct sockaddr*)&acfd_caddr.client_addr,&clientlen))<0)
		{
			perror("accept failed");
			return -1;
		}

		//printf("IP:%s,端口号：%d断开连接\n",inet_ntoa(client_addr.sin_addr),ntohs(client_addr.sin_port));

		puts("创建新线程");
		pthread_create(&tid,NULL,(void *)do_client,&acfd_caddr);


	}

	pthread_mutex_destroy(&mutex);
	return 0;
}
//线程处理函数-----------------------------------------------
void do_client(struct fd_addr* arg)
{ 
	int fd=arg->acceptfd;
	pthread_detach(pthread_self());
	accout_password ap_msg;
	int ret;
	//打印客户端信息
	//struct newfd_cl_addr * p=(struct newfd_cl_addr*)arg;
	printf("IP:%s,端口号：%d已经连接\n",inet_ntoa(arg->client_addr.sin_addr),ntohs(arg->client_addr.sin_port));
	while(1)
	{
		if((ret=recv(fd,&ap_msg,sizeof(ap_msg),0))>0)
		{
			switch(ap_msg.type){
			case SIGIN:
				do_sigin(fd,arg,&ap_msg);//注册函数
				break;
			case LOGIN:
				do_login(fd,arg,&ap_msg);//用户登录函数
				break;
			case ADMINLG:
				do_adminlogin(fd,arg,&ap_msg);//管理员登录
				break;
			default:
				break;
			}
		}
		else
		{
			printf("IP:%s,端口号：%d断开连接\n",inet_ntoa(arg->client_addr.sin_addr),ntohs(arg->client_addr.sin_port));
			goto ERR;
		}
	}
ERR:
	close(arg->acceptfd);
	pthread_exit(0);
}

//注册函数---------------
void do_sigin(int fd,struct fd_addr*arg,accout_password* p)
{
	//printf("%s:%d\n",p->name,p->password);
	pthread_mutex_lock(&mutex);//加锁
	bzero(sql,sizeof(sql));

	sprintf(sql,"insert into password values('%s','%s');",p->name,p->password);
	bzero(p,sizeof(accout_password));
	if(sqlite3_exec(arg->newdb,sql,NULL,NULL,&errmsg)!=SQLITE_OK)
	{
		printf("%s\n",errmsg);
		strcpy(p->password,"no");
	}
	else
	{
		puts("用户注册成功");
		strcpy(p->password,"ok");
	}

	pthread_mutex_unlock(&mutex);//解锁
	do
	{
		ret=send(fd,p,sizeof(accout_password),0);
	}while(ret<0&&EINTR==errno);
	if(ret<0)
	{
		puts("sigin_send failed");
		return ;
	}
	return ;
} 
//用户登录函数-------------------
int do_login(int fd,struct fd_addr*arg,accout_password*p)
{
	char **resultp;
	int nrow;
	int ncloumn;
	//printf("name:%s,password:%s\n",p->name,p->password);
	pthread_mutex_lock(&mutex);//加锁

	bzero(sql,sizeof(sql));
	sprintf(sql,"select *from password where username='%s' and password='%s';",p->name,p->password);
	//	printf("%s\n",sql);
	if((sqlite3_get_table(arg->newdb,sql,&resultp,&nrow,&ncloumn,&errmsg))!=SQLITE_OK)//利用sqlite3_get_table可以查询是否有该用户
	{
		printf("get_table:%s\n",errmsg);
		return -1; 
	}
	else{
		puts("get_table ok!");
	}
	pthread_mutex_unlock(&mutex);//解锁
	//查询成功，有该用户
	if(nrow==1)
	{
		strcpy(p->password,"ok");
		do
		{
			ret=send(fd,p,sizeof(accout_password),0);
		}while(ret<0&&EINTR==errno);
		if(ret<0)
		{
			puts("login_send failed");
			return -1;
		}
	}
	//用户名或者密码错误
	if(nrow==0)
	{	
		strcpy(p->password,"no");
		do
		{
			ret=send(fd,p,sizeof(accout_password),0);
		}while(ret<0&&EINTR==errno);
		if(ret<0)
		{
			puts("login_send failed");
		}
		return -1;
	}
	//此时用户登录成功------------------

	bzero(&staff_MSG,sizeof(staff_MSG));
	while(recv(fd,&staff_MSG,sizeof(staff_MSG),0)>0)
	{

		printf("cmd:%d\n",staff_MSG.cmd);//后期删除该句
		switch(staff_MSG.cmd){
		case MODIFY:
			do_modify(fd,arg);//修改函数
			break;
		case LOOK:
			do_look(fd,arg);//查询函数
			break;
		case DEL:
			do_del(fd,arg);//删除函数
		default:
			break;
		}
	}
	return 0 ;
}
//管理员登录函数--------------------------
int do_adminlogin(int fd,struct fd_addr*arg,accout_password*p)
{
	printf("admin%s %s\n",p->name,p->password);
	if((strcmp(p->name,"admin")==0)&&(strcmp(p->password,"0000")==0))
	{
		puts("管理员登陆成功");
		strcpy(p->password,"ok");
		do
		{
			ret=send(fd,p,sizeof(accout_password),0);
		}while(ret<0&&EINTR==errno);
		if(ret<0)
		{
			puts("login_send failed");
			return -1;
		}

		bzero(&staff_MSG,sizeof(staff_MSG));
		while(recv(fd,&staff_MSG,sizeof(staff_MSG),0)>0)
		{

			printf("cmd:%d\n",staff_MSG.cmd);//后期删除该句
			switch(staff_MSG.cmd){
			case INSERT:
				do_insert(fd,arg);//插入函数
				break;
			case MODIFY:
				do_modify(fd,arg);//修改函数
				break;
			case LOOK:
				do_look(fd,arg);//查询函数
				break;
			case DEL:
				do_del(fd,arg);//删除函数
			default:
				break;
			}
		}
	}
	else
	{
		strcpy(p->password,"no");
		do
		{
			ret=send(fd,p,sizeof(accout_password),0);
		}while(ret<0&&EINTR==errno);
		if(ret<0)
		{
			puts("adminlogin_send failed");
			return -1;
		}
	}
	return 0;
}
//插入函数------------------
int do_insert(int fd,struct fd_addr*arg)
{
	//printf("%d %s %c %d %f\n",staff_MSG.id,staff_MSG.name,staff_MSG.sex,staff_MSG.iphone,staff_MSG.salary);
	bzero(sql,sizeof(sql));
	sprintf(sql,"insert into staffinfo values(%d,'%s','%c',%d,%f);",\
			staff_MSG.id,staff_MSG.name,staff_MSG.sex,staff_MSG.iphone,staff_MSG.salary);
	//	printf("%s\n",sql);
	if(sqlite3_exec(arg->newdb,sql,NULL,NULL,&errmsg)!=SQLITE_OK)
	{
		printf("do_insert:%s\n",errmsg);
		strcpy(staff_MSG.name,"no");
	}
	else
	{
		puts("插入成功");
		strcpy(staff_MSG.name,"ok");
	}
	do
	{
		ret=send(fd,&staff_MSG,sizeof(staff_MSG),0);
	}while(ret<0&&EINTR==errno);
	if(ret<0)
	{
		puts("do_insert_send failed");
		return -1;
	}
	return 0;
}
//修改函数----------------
int do_modify(int fd,struct fd_addr*arg)
{
	bzero(sql,sizeof(sql));
	sprintf(sql,"update staffinfo set id=%d,name='%s',sex='%c',iphone=%d,salary=%f where name='%s'",\
			staff_MSG.id,staff_MSG.name,staff_MSG.sex,staff_MSG.iphone,staff_MSG.salary,staff_MSG.name);
	printf("%s\n",sql);
	if(sqlite3_exec(arg->newdb,sql,NULL,NULL,&errmsg)!=SQLITE_OK)
	{
		printf("do_modify:%s\n",errmsg);
	}
	else
	{
		puts("修改成功");
	}
	return 0;
} 
//查询函数
int do_look(int fd,struct fd_addr*arg)
{
	char **resultp;
	int nrow;
	int ncloumn;
	bzero(sql,sizeof(sql));
	sprintf(sql,"select * from staffinfo where name='%s'",staff_MSG.name);
	if((sqlite3_get_table(arg->newdb,sql,&resultp,&nrow,&ncloumn,&errmsg))!=SQLITE_OK)//利用sqlite3_get_table可以查询是否有该用户
	{
		printf("get_table:%s\n",errmsg);
		return -1; 
	}
	else{
		puts("do_look get_table ok!");
	}
	//查询成功，有该用户
	if(nrow==1)
	{
		staff_MSG.cmd=0;
		do
		{
			ret=send(fd,&staff_MSG,sizeof(staff_msg),0);
		}while(ret<0&&EINTR==errno);
		if(ret<0)
		{
			puts("do_look_send failed");
		}
	}
	//用户名或者密码错误
	if(nrow==0)
	{	
		staff_MSG.cmd=-1;
		do
		{
			ret=send(fd,&staff_MSG,sizeof(staff_msg),0);
		}while(ret<0&&EINTR==errno);
		if(ret<0)
		{
			puts("do_look_send failed");
		}
		return -1;
	}

	bzero(sql,sizeof(sql));
	sprintf(sql,"select * from staffinfo where name='%s';",staff_MSG.name);
	//printf("%s\n",sql);
	if(sqlite3_exec(arg->newdb,sql,history_callback,(void *)&fd,&errmsg)!=SQLITE_OK)
	{
		printf("do_insert:%s\n",errmsg);
		puts("查询失败");
		return -1;
	}
	puts("查询完成");
	return 0;
}
//回调函数;将查询的结果发送到客户端
int  history_callback(void *arg,int f_num,char**f_value,char**f_name)
{
	
	staff_MSG.id=atoi(f_value[0]);
	int fd=(*(int *)arg);
	strcpy(staff_MSG.name,f_value[1]);
	staff_MSG.sex=*f_value[2];
	staff_MSG.iphone=atoi(f_value[3]);
	staff_MSG.salary=atof(f_value[4]);
	//printf("send之前的数据：%d %s %c %d %f\n",staff_MSG.id,staff_MSG.name,staff_MSG.sex,staff_MSG.iphone,staff_MSG.salary);
	do
	{
		ret=send(fd,&staff_MSG,sizeof(staff_MSG),0);
	}while(ret<0&&EINTR==errno);
	if(ret<0)
	{
		puts("look send failed");
		return -1;
	}
	return 0;
}
//删除
int do_del(int fd,struct fd_addr*arg)
{
	puts("进入删除函数");
	char **resultp;
	int nrow;
	int ncloumn;
	bzero(sql,sizeof(sql));
	sprintf(sql,"select * from staffinfo where name='%s'",staff_MSG.name);
	if((sqlite3_get_table(arg->newdb,sql,&resultp,&nrow,&ncloumn,&errmsg))!=SQLITE_OK)//利用sqlite3_get_table可以查询是否有该用户
	{
		printf("get_table:%s\n",errmsg);
		return -1; 
	}
	else{
		puts("do_look get_table ok!");
	}
	//查询成功，有该用户
	//用户名或者密码错误
	if(nrow==0)
	{	
		staff_MSG.cmd=-1;
		do
		{
			ret=send(arg->acceptfd,&staff_MSG,sizeof(staff_msg),0);
		}while(ret<0&&EINTR==errno);
		if(ret<0)
		{
			puts("do_look_send failed");
		}
		return -1;
	}
	bzero(sql,sizeof(sql));
	sprintf(sql,"delete from staffinfo where name='%s';",staff_MSG.name);
	if(sqlite3_exec(arg->newdb,sql,NULL,NULL,&errmsg)!=SQLITE_OK)
	{
		printf("do_del:%s\n",errmsg);
		puts("删除失败");
		staff_MSG.id=-1;
		send(fd,&staff_MSG,sizeof(staff_MSG),0);
		return -1;
	}
	puts("删除完成");
	staff_MSG.id=0;
	send(fd,&staff_MSG,sizeof(staff_MSG),0);

	return 0;


}
